const { json, getCache, generatePredictions } = require('./_shared');

exports.handler = async (event) => {
  try {
    const force = event.queryStringParameters?.refresh === '1';
    const cached = await getCache();
    if (cached && !force) return json(200, cached);
    const fresh = await generatePredictions();
    return json(200, fresh);
  } catch (err) {
    try {
      const cached = await getCache();
      if (cached) return json(200, { ...cached, warning: err.message });
    } catch (_) {}
    return json(500, { error: err.message || 'Prediction function failed' });
  }
};

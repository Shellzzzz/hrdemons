const { json, generatePredictions } = require('./_shared');

exports.config = {
  // Netlify cron uses UTC. 10:00 and 19:00 UTC = 6AM and 3PM Eastern during daylight saving time.
  schedule: '0 10,19 * * *'
};

exports.handler = async () => {
  try {
    const fresh = await generatePredictions();
    return json(200, { ok: true, lastUpdated: fresh.lastUpdated, count: fresh.predictions.length });
  } catch (err) {
    return json(500, { ok: false, error: err.message || 'Scheduled update failed' });
  }
};

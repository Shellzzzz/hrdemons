HR DEMONS FINAL FIX

UPLOAD THE WHOLE FOLDER to Netlify, not just index.html.

Required structure:
index.html
package.json
netlify.toml
netlify/functions/_shared.js
netlify/functions/predictions.js
netlify/functions/updatePredictions.js

Netlify settings:
1. Site settings -> Environment variables
2. Add: ANTHROPIC_API_KEY = your NEW Claude API key
3. Optional: CLAUDE_MODEL = claude-sonnet-4-6
4. Redeploy site

Test these URLs after deploy:
https://YOUR-SITE.netlify.app/.netlify/functions/predictions?refresh=1
https://YOUR-SITE.netlify.app/.netlify/functions/updatePredictions

Scheduled updates:
The updatePredictions function is scheduled at 10:00 UTC and 19:00 UTC,
which equals 6AM and 3PM Eastern during daylight saving time.

Important:
Rotate/delete your old Claude key because it was exposed in your old index.html.
